var group___m_c_p100_datamodel =
[
    [ "StateData", "struct_state_data.html", [
      [ "cavity_index", "struct_state_data.html#ad96ea817c617eee3ae68df463afffc0b", null ],
      [ "encoder_position", "struct_state_data.html#a9f1934960cc34a29438e56ca5bb7532f", null ],
      [ "encoder_speed", "struct_state_data.html#a30afe0c9236110c0a12703145b8b244f", null ],
      [ "port_index", "struct_state_data.html#aae56efa17280ca97806fb7a4d89e3fa7", null ],
      [ "reference_index", "struct_state_data.html#a71b90382ee75d82594cf895074de81a4", null ]
    ] ],
    [ "OutputControlData", "struct_output_control_data.html", [
      [ "output_channel", "struct_output_control_data.html#a932e19df80036da32793b4511a909053", null ],
      [ "output_delay", "struct_output_control_data.html#a5652290eb74ef6df7ef4d7b6eed3cdf2", null ],
      [ "output_duration", "struct_output_control_data.html#a301050bcd9c63d351851b088643087a2", null ],
      [ "port_1_maximum_threshold", "struct_output_control_data.html#a234c2061d53093d910b25da515198f95", null ],
      [ "port_1_minimum_threshold", "struct_output_control_data.html#a15f60314df89ec92c9578b760609922f", null ],
      [ "port_2_maximum_threshold", "struct_output_control_data.html#af72b684376868840746cbf1194094e5e", null ],
      [ "port_2_minimum_threshold", "struct_output_control_data.html#ac95ba551ebb16c7c9a3cf127b62a857b", null ],
      [ "port_3_maximum_threshold", "struct_output_control_data.html#aaec83fba488f2d3028dd3ecb598ae170", null ],
      [ "port_3_minimum_threshold", "struct_output_control_data.html#ac8ab6c6d390a5f87d803b296e975506d", null ],
      [ "port_4_maximum_threshold", "struct_output_control_data.html#aebfd1c48b3223edfd635c9b267ca5095", null ],
      [ "port_4_minimum_threshold", "struct_output_control_data.html#a9eb4e9964c4c5d72df746c50e1adcdae", null ],
      [ "QA_count", "struct_output_control_data.html#a5db6aacde358ee31819284aa9074600a", null ]
    ] ],
    [ "Measurement", "struct_measurement.html", [
      [ "count", "struct_measurement.html#a86988a65e0d3ece7990c032c159786d6", null ],
      [ "distance", "struct_measurement.html#a6e8ed16cd5555f4a5d285f2608ca1b6f", null ],
      [ "end", "struct_measurement.html#afbcd798d035e37e733b567c2b0cb96dc", null ],
      [ "start", "struct_measurement.html#a171a2b5d11b1a5891c38a98ac731a161", null ],
      [ "thickness", "struct_measurement.html#a30e08f58c50be7646e98cc6145acd36b", null ]
    ] ],
    [ "SurfaceMeasurement", "struct_surface_measurement.html", [
      [ "distance1", "struct_surface_measurement.html#a9102faa56a92113485be3bc8fa73b05b", null ],
      [ "distance2", "struct_surface_measurement.html#a6746f9b3275e8f2a7bc7b6691df28e18", null ],
      [ "encoder_pos", "struct_surface_measurement.html#a1eac0e5461196f7e8e9c4ec069dec4f0", null ],
      [ "tilt", "struct_surface_measurement.html#a8b07a56c9e764ad9c06fe53521fcf86d", null ]
    ] ],
    [ "StatisticalMeasurement", "struct_statistical_measurement.html", [
      [ "average", "struct_statistical_measurement.html#a7cabb8708edc36bb4d9ddd7e617891d2", null ],
      [ "cavity_index", "struct_statistical_measurement.html#ad96ea817c617eee3ae68df463afffc0b", null ],
      [ "reference_index", "struct_statistical_measurement.html#a71b90382ee75d82594cf895074de81a4", null ],
      [ "rejection_status", "struct_statistical_measurement.html#a8eed7df43334ba29eed3c3056b5f82ab", null ],
      [ "sample_count", "struct_statistical_measurement.html#ab3ed5e57dfce79a9a747fe47d860481e", null ],
      [ "thickness_max", "struct_statistical_measurement.html#a1b6e6c9b6a1a1741d67327f2ac324275", null ],
      [ "thickness_min", "struct_statistical_measurement.html#a6d07cdbfbbf6768db04ddd353d99cf6a", null ],
      [ "uncompensated", "struct_statistical_measurement.html#af0c0bf371236b5dcabe93bb828325b64", null ]
    ] ],
    [ "StatisticalMeasurementEx", "struct_statistical_measurement_ex.html", [
      [ "distance_diff", "struct_statistical_measurement_ex.html#a6f9f6efa6119ad898563a5312cdd6931", null ],
      [ "intensity", "struct_statistical_measurement_ex.html#a2dfe87f3417747242e8f043dd4f3fb59", null ],
      [ "statistics", "struct_statistical_measurement_ex.html#a9f1f851b72ada9942e6e48eac8135468", null ],
      [ "tilt", "struct_statistical_measurement_ex.html#a8b07a56c9e764ad9c06fe53521fcf86d", null ],
      [ "uncompensated_thickness", "struct_statistical_measurement_ex.html#ac8ad92c5af1616c08bdfbca1f986d94c", null ],
      [ "unscaled_thickness", "struct_statistical_measurement_ex.html#a5efdbb821bfca26c3f60aebdd32afe65", null ]
    ] ],
    [ "Probe", "struct_probe.html", [
      [ "angle_offset", "struct_probe.html#ae264c7877d4cb98b05f20efc15582ae7", null ],
      [ "angle_scale", "struct_probe.html#aec3adc66b95b7087fcd9b930871d1eea", null ],
      [ "delay", "struct_probe.html#a01a88e92d700dc082aa8d89964d9445d", null ],
      [ "detection_mode", "struct_probe.html#ad253371e33401f5af17291993aaefa43", null ],
      [ "distance_offset", "struct_probe.html#aa45e48b5bbe4415cbdbf1ac2006fe47d", null ],
      [ "distance_scale", "struct_probe.html#a280df036344006a64f38a9140751177e", null ],
      [ "measure_mode", "struct_probe.html#aa09c85eb5169708f746b539c385b2ef1", null ],
      [ "pulse_delay", "struct_probe.html#a89b83b23f6b506116a94471e237bae1e", null ],
      [ "pulse_frequency", "struct_probe.html#a1feed3854c6dc475debd5b0d78fd6c35", null ],
      [ "pulse_width", "struct_probe.html#a3518827b17ce0b14d217385dc01c673e", null ],
      [ "spacing_threshold", "struct_probe.html#abbc8c0608a7063fd9c897d1b3507bfe6", null ],
      [ "thickness_offset", "struct_probe.html#aacde5718d404b030e817fc285b87f896", null ],
      [ "thickness_scale", "struct_probe.html#aa4312d0bcc1c73755d6925e5991b7677", null ],
      [ "threshold", "struct_probe.html#aa63db45b7c328128e07cd4d0f86f59df", null ],
      [ "tilt_offset", "struct_probe.html#a877ba7fc59debb5291bd55fcaabfc2d7", null ],
      [ "tilt_scale", "struct_probe.html#a6f4a3c5b4413391879661599b5b32c31", null ],
      [ "trigger_mode", "struct_probe.html#ab540fde17c8903529f5fd9d3e650cfbf", null ],
      [ "window", "struct_probe.html#a6b307b5083cf92aca29549d780b44bd5", null ]
    ] ],
    [ "MAX_PROBES_PER_CONTROLUNIT", "group___m_c_p100-datamodel.html#ga9f47bdb28142f401329b18f02cb75b82", null ],
    [ "PROFILE_LENGTH", "group___m_c_p100-datamodel.html#ga4ca32086938818a06edd534b059fa9b8", null ],
    [ "EMeasurementOutputMode", "group___m_c_p100-datamodel.html#ga56e4db181e1c0a434bc75ee312f230ab", [
      [ "RAW", "group___m_c_p100-datamodel.html#gga56e4db181e1c0a434bc75ee312f230ababdeded99fe7d3f2773014a9a2cfb73d7", null ],
      [ "EXTENDED_STATISTICAL", "group___m_c_p100-datamodel.html#gga56e4db181e1c0a434bc75ee312f230abaae4890dcb785f0c38c770ea8aa82b0b5", null ],
      [ "SURFACE_STATISTICAL", "group___m_c_p100-datamodel.html#gga56e4db181e1c0a434bc75ee312f230aba1bd8277481998d84ba2aa2c731db2942", null ]
    ] ],
    [ "EOutputCommandTypes", "group___m_c_p100-datamodel.html#ga9ade99991233b645206f3e125a21f524", [
      [ "SET_OUTPUT_CONFIGURATION", "group___m_c_p100-datamodel.html#gga9ade99991233b645206f3e125a21f524a1eee79783e70abe964a4115ec34697a7", null ],
      [ "ACTIVATE_OUTPUT", "group___m_c_p100-datamodel.html#gga9ade99991233b645206f3e125a21f524a8f7f2a4a6b2af00a66fec6e59ee94e42", null ],
      [ "DEACTIVATE_OUTPUT", "group___m_c_p100-datamodel.html#gga9ade99991233b645206f3e125a21f524a39320d4eab10a98c31873543b89d2e5f", null ],
      [ "QA_ACTIVATE_OUTPUT", "group___m_c_p100-datamodel.html#gga9ade99991233b645206f3e125a21f524a206f7380f7a126b4a782924293d48258", null ],
      [ "CLEAR_OUTPUT_SETTINGS", "group___m_c_p100-datamodel.html#gga9ade99991233b645206f3e125a21f524aa0e2b67d891a5a6365da1916a3636c77", null ]
    ] ],
    [ "ERejectionStatus", "group___m_c_p100-datamodel.html#gaa659981ca993dd55b3b5b6a195840199", [
      [ "NOT_REJECTED", "group___m_c_p100-datamodel.html#ggaa659981ca993dd55b3b5b6a195840199a82b30eed747dcc6b7ef7031fba31da2e", null ],
      [ "MIN_REJECTION", "group___m_c_p100-datamodel.html#ggaa659981ca993dd55b3b5b6a195840199a12050fd1dc50ed27bf87fb539a1f93e9", null ],
      [ "MAX_REJECTION", "group___m_c_p100-datamodel.html#ggaa659981ca993dd55b3b5b6a195840199aec988634ad907db1287d7138ee3ec565", null ],
      [ "QA_REJECTION", "group___m_c_p100-datamodel.html#ggaa659981ca993dd55b3b5b6a195840199a078c5b2d58502d040a13424a41bb0243", null ]
    ] ],
    [ "ESamplingMode", "group___m_c_p100-datamodel.html#ga9f8c906cc18905d58f04c8e4a94902cf", [
      [ "FREE_RUN", "group___m_c_p100-datamodel.html#gga9f8c906cc18905d58f04c8e4a94902cfa4accd9d48b967f6898a2c87c3f22fdc4", null ],
      [ "ENCODER", "group___m_c_p100-datamodel.html#gga9f8c906cc18905d58f04c8e4a94902cfae9081fafd7de43a5c3f98f8f9b59f86f", null ]
    ] ],
    [ "EStateChangedTypes", "group___m_c_p100-datamodel.html#gafbfcb1a7d32c50ae0f78f4119c9ed4ad", [
      [ "CONTROL_UNIT_DISCOVERED", "group___m_c_p100-datamodel.html#ggafbfcb1a7d32c50ae0f78f4119c9ed4adae2c0a8ef6ca539d35a8cfe7b36107077", null ],
      [ "CONTROL_UNIT_MISSING", "group___m_c_p100-datamodel.html#ggafbfcb1a7d32c50ae0f78f4119c9ed4ada5b19d4592d73731eea8566ce99c69780", null ],
      [ "CONTROL_UNIT_RECONNECTED", "group___m_c_p100-datamodel.html#ggafbfcb1a7d32c50ae0f78f4119c9ed4ada686400382afd5a147be97098d48d8a33", null ],
      [ "PROBE_DISCOVERED", "group___m_c_p100-datamodel.html#ggafbfcb1a7d32c50ae0f78f4119c9ed4adadf4875661549c6bed0583379e48526e2", null ],
      [ "PROBE_MISSING", "group___m_c_p100-datamodel.html#ggafbfcb1a7d32c50ae0f78f4119c9ed4ada14087c4d706cbe493f9d8b8384ce9090", null ],
      [ "TRIGGER1_ACTIVATED", "group___m_c_p100-datamodel.html#ggafbfcb1a7d32c50ae0f78f4119c9ed4ada85edbb68752f0e1574fe46bde29177eb", null ],
      [ "TRIGGER2_ACTIVATED", "group___m_c_p100-datamodel.html#ggafbfcb1a7d32c50ae0f78f4119c9ed4ada03bbf92c82c7522ea9e6575500a49f04", null ],
      [ "TRIGGER3_ACTIVATED", "group___m_c_p100-datamodel.html#ggafbfcb1a7d32c50ae0f78f4119c9ed4adad32ca2ef2654ae1848d71190d1c6669f", null ],
      [ "TRIGGER4_ACTIVATED", "group___m_c_p100-datamodel.html#ggafbfcb1a7d32c50ae0f78f4119c9ed4adaf122eabd3246e112db1aff819d7f67e6", null ],
      [ "TRIGGER5_ACTIVATED", "group___m_c_p100-datamodel.html#ggafbfcb1a7d32c50ae0f78f4119c9ed4adae93762376ff55751fe84a989c2a19ea5", null ]
    ] ]
];