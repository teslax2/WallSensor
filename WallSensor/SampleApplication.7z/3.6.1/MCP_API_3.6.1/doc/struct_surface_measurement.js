var struct_surface_measurement =
[
    [ "distance1", "struct_surface_measurement.html#a9102faa56a92113485be3bc8fa73b05b", null ],
    [ "distance2", "struct_surface_measurement.html#a6746f9b3275e8f2a7bc7b6691df28e18", null ],
    [ "encoder_pos", "struct_surface_measurement.html#a1eac0e5461196f7e8e9c4ec069dec4f0", null ],
    [ "tilt", "struct_surface_measurement.html#a8b07a56c9e764ad9c06fe53521fcf86d", null ]
];