var group___m_c_p100_callbacks =
[
    [ "MeasurementAcquired", "group___m_c_p100-callbacks.html#ga29d558c02d6ebfd643ad52f33d7ca340", null ],
    [ "StateChanged", "group___m_c_p100-callbacks.html#gad56ef343187dd55c0634a8a6b314d0b4", null ],
    [ "StatisticalMeasurementExAcquired", "group___m_c_p100-callbacks.html#gadd17b10df6a64708fcf86ddf7abe90f1", null ],
    [ "SurfaceMeasurementAcquired", "group___m_c_p100-callbacks.html#ga8c183c6e532272dc1ed6ac5a7cd4a530", null ]
];