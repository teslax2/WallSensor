var struct_output_control_data =
[
    [ "output_channel", "struct_output_control_data.html#a932e19df80036da32793b4511a909053", null ],
    [ "output_delay", "struct_output_control_data.html#a5652290eb74ef6df7ef4d7b6eed3cdf2", null ],
    [ "output_duration", "struct_output_control_data.html#a301050bcd9c63d351851b088643087a2", null ],
    [ "port_1_maximum_threshold", "struct_output_control_data.html#a234c2061d53093d910b25da515198f95", null ],
    [ "port_1_minimum_threshold", "struct_output_control_data.html#a15f60314df89ec92c9578b760609922f", null ],
    [ "port_2_maximum_threshold", "struct_output_control_data.html#af72b684376868840746cbf1194094e5e", null ],
    [ "port_2_minimum_threshold", "struct_output_control_data.html#ac95ba551ebb16c7c9a3cf127b62a857b", null ],
    [ "port_3_maximum_threshold", "struct_output_control_data.html#aaec83fba488f2d3028dd3ecb598ae170", null ],
    [ "port_3_minimum_threshold", "struct_output_control_data.html#ac8ab6c6d390a5f87d803b296e975506d", null ],
    [ "port_4_maximum_threshold", "struct_output_control_data.html#aebfd1c48b3223edfd635c9b267ca5095", null ],
    [ "port_4_minimum_threshold", "struct_output_control_data.html#a9eb4e9964c4c5d72df746c50e1adcdae", null ],
    [ "QA_count", "struct_output_control_data.html#a5db6aacde358ee31819284aa9074600a", null ]
];