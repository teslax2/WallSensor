var NAVTREE =
[
  [ "MCP100API", "index.html", [
    [ "FocalSpec MCP100API", "index.html", [
      [ "Copyright", "index.html#Copyright", null ],
      [ "Version", "index.html#Version", null ],
      [ "Introduction", "index.html#Introduction", null ],
      [ "Package", "index.html#Package", [
        [ "doc", "index.html#doc", null ],
        [ "build", "index.html#build", null ],
        [ "ExampleApplication", "index.html#ExampleApplication", null ]
      ] ],
      [ "Usage", "index.html#Usage", null ],
      [ "API Version History", "index.html#VersionHistory", null ],
      [ "Further Reading", "index.html#FurtherReading", null ]
    ] ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';