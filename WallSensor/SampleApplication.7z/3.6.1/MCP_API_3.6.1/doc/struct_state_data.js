var struct_state_data =
[
    [ "cavity_index", "struct_state_data.html#ad96ea817c617eee3ae68df463afffc0b", null ],
    [ "encoder_position", "struct_state_data.html#a9f1934960cc34a29438e56ca5bb7532f", null ],
    [ "encoder_speed", "struct_state_data.html#a30afe0c9236110c0a12703145b8b244f", null ],
    [ "port_index", "struct_state_data.html#aae56efa17280ca97806fb7a4d89e3fa7", null ],
    [ "reference_index", "struct_state_data.html#a71b90382ee75d82594cf895074de81a4", null ]
];