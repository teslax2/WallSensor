var annotated_dup =
[
    [ "Measurement", "struct_measurement.html", "struct_measurement" ],
    [ "OutputControlData", "struct_output_control_data.html", "struct_output_control_data" ],
    [ "Probe", "struct_probe.html", "struct_probe" ],
    [ "StateData", "struct_state_data.html", "struct_state_data" ],
    [ "StatisticalMeasurement", "struct_statistical_measurement.html", "struct_statistical_measurement" ],
    [ "StatisticalMeasurementEx", "struct_statistical_measurement_ex.html", "struct_statistical_measurement_ex" ],
    [ "SurfaceMeasurement", "struct_surface_measurement.html", "struct_surface_measurement" ]
];