var struct_measurement =
[
    [ "count", "struct_measurement.html#a86988a65e0d3ece7990c032c159786d6", null ],
    [ "distance", "struct_measurement.html#a6e8ed16cd5555f4a5d285f2608ca1b6f", null ],
    [ "end", "struct_measurement.html#afbcd798d035e37e733b567c2b0cb96dc", null ],
    [ "start", "struct_measurement.html#a171a2b5d11b1a5891c38a98ac731a161", null ],
    [ "thickness", "struct_measurement.html#a30e08f58c50be7646e98cc6145acd36b", null ]
];