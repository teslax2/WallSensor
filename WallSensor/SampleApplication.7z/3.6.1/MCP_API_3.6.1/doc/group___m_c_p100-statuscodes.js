var group___m_c_p100_statuscodes =
[
    [ "MCP_ERROR_ALREADY_INITIALIZED", "group___m_c_p100-statuscodes.html#ga108dee9cb4b5cc092dd6970134c837d1", null ],
    [ "MCP_ERROR_API_NOT_OPEN", "group___m_c_p100-statuscodes.html#ga81e3b3a9898571d3d6487fbddd5d796c", null ],
    [ "MCP_ERROR_FILE_INCOMPATIBILE", "group___m_c_p100-statuscodes.html#gae8b4b2a7b2526a498a4dd5b9997e5712", null ],
    [ "MCP_ERROR_FILE_NOT_FOUND", "group___m_c_p100-statuscodes.html#gaca9b3824622bd451517f85511ee2410c", null ],
    [ "MCP_ERROR_IMAGE_NOT_READY", "group___m_c_p100-statuscodes.html#ga00ae020a521d775e66529fb2cb47e2dc", null ],
    [ "MCP_ERROR_INCOMPATIBLE_PROBE_COMMUNICATION_PROTOCOL", "group___m_c_p100-statuscodes.html#gaca7c50f151344f30bf5bf28e68b6f434", null ],
    [ "MCP_ERROR_INVALID_SERIAL", "group___m_c_p100-statuscodes.html#ga39aa25723eef2227accc01faa521d535", null ],
    [ "MCP_ERROR_MEM_ALLOCATION_FAILED", "group___m_c_p100-statuscodes.html#ga7839b634c425396ba748035a92c87e23", null ],
    [ "MCP_ERROR_NETWORK_END_POINT_CONNECTION_FAILED", "group___m_c_p100-statuscodes.html#ga481d13bc774878e41c7d045b6335f4a9", null ],
    [ "MCP_ERROR_NETWORK_END_POINT_MESSAGING_FAILED", "group___m_c_p100-statuscodes.html#ga18ac68fb897d1b643f6ec575afd09133", null ],
    [ "MCP_ERROR_NETWORK_LIBRARY_CLOSE_FAILED", "group___m_c_p100-statuscodes.html#ga7f338cedcec88100361cb7a686cf220c", null ],
    [ "MCP_ERROR_NETWORK_LIBRARY_LOAD_FAILED", "group___m_c_p100-statuscodes.html#gab2f57b71b39b6b3bd36768803d6cdc19", null ],
    [ "MCP_ERROR_NETWORK_SOCKET_INITIALIZATION_FAILED", "group___m_c_p100-statuscodes.html#ga0cb0e33f06f6ba4bd267950756e05300", null ],
    [ "MCP_ERROR_NOT_IMPLEMENTED", "group___m_c_p100-statuscodes.html#ga1bd89fedfbe5c0944341cc48e6b28792", null ],
    [ "MCP_ERROR_TIMEOUT", "group___m_c_p100-statuscodes.html#gab436b8e551ee5b4514d3939309991361", null ],
    [ "MCP_ERROR_UNKNOWN_CONTROL_UNIT_SERIAL", "group___m_c_p100-statuscodes.html#gaafe88dd1be34fa05ef1dfab9f92f21a4", null ],
    [ "MCP_ERROR_UNKNOWN_PROBE_SERIAL", "group___m_c_p100-statuscodes.html#gaee3cf53282531b9ee2fdbcd6df90f372", null ],
    [ "MCP_OK", "group___m_c_p100-statuscodes.html#ga056d8f68e8134a13a20a2572ff1c4c2b", null ]
];