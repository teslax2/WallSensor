var struct_statistical_measurement =
[
    [ "average", "struct_statistical_measurement.html#a7cabb8708edc36bb4d9ddd7e617891d2", null ],
    [ "cavity_index", "struct_statistical_measurement.html#ad96ea817c617eee3ae68df463afffc0b", null ],
    [ "reference_index", "struct_statistical_measurement.html#a71b90382ee75d82594cf895074de81a4", null ],
    [ "rejection_status", "struct_statistical_measurement.html#a8eed7df43334ba29eed3c3056b5f82ab", null ],
    [ "sample_count", "struct_statistical_measurement.html#ab3ed5e57dfce79a9a747fe47d860481e", null ],
    [ "thickness_max", "struct_statistical_measurement.html#a1b6e6c9b6a1a1741d67327f2ac324275", null ],
    [ "thickness_min", "struct_statistical_measurement.html#a6d07cdbfbbf6768db04ddd353d99cf6a", null ],
    [ "uncompensated", "struct_statistical_measurement.html#af0c0bf371236b5dcabe93bb828325b64", null ]
];