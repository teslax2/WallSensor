var searchData=
[
  ['activate_5foutput',['ACTIVATE_OUTPUT',['../group___m_c_p100-datamodel.html#gga9ade99991233b645206f3e125a21f524a8f7f2a4a6b2af00a66fec6e59ee94e42',1,'DataModel.h']]],
  ['angle_5foffset',['angle_offset',['../struct_probe.html#ae264c7877d4cb98b05f20efc15582ae7',1,'Probe']]],
  ['angle_5fscale',['angle_scale',['../struct_probe.html#aec3adc66b95b7087fcd9b930871d1eea',1,'Probe']]],
  ['average',['average',['../struct_statistical_measurement.html#a7cabb8708edc36bb4d9ddd7e617891d2',1,'StatisticalMeasurement']]],
  ['api_20data_20structures',['API data structures',['../group___m_c_p100-datamodel.html',1,'']]],
  ['available_20functions',['Available functions',['../group___m_c_p100-routines.html',1,'']]]
];
