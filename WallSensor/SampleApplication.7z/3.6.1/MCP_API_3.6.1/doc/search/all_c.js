var searchData=
[
  ['sample_5fcount',['sample_count',['../struct_statistical_measurement.html#ab3ed5e57dfce79a9a747fe47d860481e',1,'StatisticalMeasurement']]],
  ['set_5foutput_5fconfiguration',['SET_OUTPUT_CONFIGURATION',['../group___m_c_p100-datamodel.html#gga9ade99991233b645206f3e125a21f524a1eee79783e70abe964a4115ec34697a7',1,'DataModel.h']]],
  ['spacing_5fthreshold',['spacing_threshold',['../struct_probe.html#abbc8c0608a7063fd9c897d1b3507bfe6',1,'Probe']]],
  ['start',['start',['../struct_measurement.html#a171a2b5d11b1a5891c38a98ac731a161',1,'Measurement']]],
  ['statechanged',['StateChanged',['../group___m_c_p100-callbacks.html#gad56ef343187dd55c0634a8a6b314d0b4',1,'Callback.h']]],
  ['statedata',['StateData',['../struct_state_data.html',1,'']]],
  ['statisticalmeasurement',['StatisticalMeasurement',['../struct_statistical_measurement.html',1,'']]],
  ['statisticalmeasurementex',['StatisticalMeasurementEx',['../struct_statistical_measurement_ex.html',1,'']]],
  ['statisticalmeasurementexacquired',['StatisticalMeasurementExAcquired',['../group___m_c_p100-callbacks.html#gadd17b10df6a64708fcf86ddf7abe90f1',1,'Callback.h']]],
  ['statistics',['statistics',['../struct_statistical_measurement_ex.html#a9f1f851b72ada9942e6e48eac8135468',1,'StatisticalMeasurementEx']]],
  ['surface_5fstatistical',['SURFACE_STATISTICAL',['../group___m_c_p100-datamodel.html#gga56e4db181e1c0a434bc75ee312f230aba1bd8277481998d84ba2aa2c731db2942',1,'DataModel.h']]],
  ['surfacemeasurement',['SurfaceMeasurement',['../struct_surface_measurement.html',1,'']]],
  ['surfacemeasurementacquired',['SurfaceMeasurementAcquired',['../group___m_c_p100-callbacks.html#ga8c183c6e532272dc1ed6ac5a7cd4a530',1,'Callback.h']]]
];
