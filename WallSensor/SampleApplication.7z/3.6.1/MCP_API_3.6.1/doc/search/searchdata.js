var indexSectionsWithContent =
{
  0: "acdefimnopqrstuw",
  1: "mops",
  2: "m",
  3: "acdeimopqrstuw",
  4: "ms",
  5: "e",
  6: "acdefmnpqrst",
  7: "acr",
  8: "f"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "enumvalues",
  7: "groups",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Enumerations",
  6: "Enumerator",
  7: "Modules",
  8: "Pages"
};

