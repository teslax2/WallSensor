var searchData=
[
  ['max_5frejection',['MAX_REJECTION',['../group___m_c_p100-datamodel.html#ggaa659981ca993dd55b3b5b6a195840199aec988634ad907db1287d7138ee3ec565',1,'DataModel.h']]],
  ['min_5frejection',['MIN_REJECTION',['../group___m_c_p100-datamodel.html#ggaa659981ca993dd55b3b5b6a195840199a12050fd1dc50ed27bf87fb539a1f93e9',1,'DataModel.h']]]
];
