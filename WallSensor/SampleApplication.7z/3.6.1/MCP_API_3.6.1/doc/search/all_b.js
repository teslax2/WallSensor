var searchData=
[
  ['return_20values_20for_20the_20api_20routines_2e',['Return values for the API routines.',['../group___m_c_p100-statuscodes.html',1,'']]],
  ['raw',['RAW',['../group___m_c_p100-datamodel.html#gga56e4db181e1c0a434bc75ee312f230ababdeded99fe7d3f2773014a9a2cfb73d7',1,'DataModel.h']]],
  ['reference_5findex',['reference_index',['../struct_state_data.html#a71b90382ee75d82594cf895074de81a4',1,'StateData::reference_index()'],['../struct_statistical_measurement.html#a71b90382ee75d82594cf895074de81a4',1,'StatisticalMeasurement::reference_index()']]],
  ['rejection_5fstatus',['rejection_status',['../struct_statistical_measurement.html#a8eed7df43334ba29eed3c3056b5f82ab',1,'StatisticalMeasurement']]]
];
