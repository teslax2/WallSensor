var searchData=
[
  ['uncompensated',['uncompensated',['../struct_statistical_measurement.html#af0c0bf371236b5dcabe93bb828325b64',1,'StatisticalMeasurement']]],
  ['uncompensated_5fthickness',['uncompensated_thickness',['../struct_statistical_measurement_ex.html#ac8ad92c5af1616c08bdfbca1f986d94c',1,'StatisticalMeasurementEx']]],
  ['unscaled_5fthickness',['unscaled_thickness',['../struct_statistical_measurement_ex.html#a5efdbb821bfca26c3f60aebdd32afe65',1,'StatisticalMeasurementEx']]]
];
