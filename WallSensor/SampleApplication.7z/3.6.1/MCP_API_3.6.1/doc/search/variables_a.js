var searchData=
[
  ['sample_5fcount',['sample_count',['../struct_statistical_measurement.html#ab3ed5e57dfce79a9a747fe47d860481e',1,'StatisticalMeasurement']]],
  ['spacing_5fthreshold',['spacing_threshold',['../struct_probe.html#abbc8c0608a7063fd9c897d1b3507bfe6',1,'Probe']]],
  ['start',['start',['../struct_measurement.html#a171a2b5d11b1a5891c38a98ac731a161',1,'Measurement']]],
  ['statistics',['statistics',['../struct_statistical_measurement_ex.html#a9f1f851b72ada9942e6e48eac8135468',1,'StatisticalMeasurementEx']]]
];
