var searchData=
[
  ['return_20values_20for_20the_20api_20routines_2e',['Return values for the API routines.',['../group___m_c_p100-statuscodes.html',1,'']]]
];
