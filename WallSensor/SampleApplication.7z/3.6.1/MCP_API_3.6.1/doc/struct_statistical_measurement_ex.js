var struct_statistical_measurement_ex =
[
    [ "distance_diff", "struct_statistical_measurement_ex.html#a6f9f6efa6119ad898563a5312cdd6931", null ],
    [ "intensity", "struct_statistical_measurement_ex.html#a2dfe87f3417747242e8f043dd4f3fb59", null ],
    [ "statistics", "struct_statistical_measurement_ex.html#a9f1f851b72ada9942e6e48eac8135468", null ],
    [ "tilt", "struct_statistical_measurement_ex.html#a8b07a56c9e764ad9c06fe53521fcf86d", null ],
    [ "uncompensated_thickness", "struct_statistical_measurement_ex.html#ac8ad92c5af1616c08bdfbca1f986d94c", null ],
    [ "unscaled_thickness", "struct_statistical_measurement_ex.html#a5efdbb821bfca26c3f60aebdd32afe65", null ]
];