var group___m_c_p100_routines =
[
    [ "McpClose", "group___m_c_p100-routines.html#ga7a393984228c8414ce8d923968c975de", null ],
    [ "McpDiscoverControlUnits", "group___m_c_p100-routines.html#ga43ab35ec4db0be6129e3a4313f4aadb7", null ],
    [ "McpDiscoverProbes", "group___m_c_p100-routines.html#ga321679ebf27f601a1a340f443344ac55", null ],
    [ "McpGetEncoderSpeed", "group___m_c_p100-routines.html#ga57c2c7009e7b90b7b914351824f6641c", null ],
    [ "McpGetProfile", "group___m_c_p100-routines.html#gaf86659cecb1e6835e348d443ecd20c4c", null ],
    [ "McpGetProperties", "group___m_c_p100-routines.html#gaf5283ade96c6d41f04bedcc5737489ef", null ],
    [ "McpOpen", "group___m_c_p100-routines.html#ga59714bfe939c6d56caba059235049ff0", null ],
    [ "McpSetEncoderDivider", "group___m_c_p100-routines.html#ga9f56edbadde5a28839f05516b598bd28", null ],
    [ "McpSetIllumination", "group___m_c_p100-routines.html#gada67958d011290fb22412bb48815a603", null ],
    [ "McpSetMeasurementOutputMode", "group___m_c_p100-routines.html#ga34d8fa770e805a21b873e33378af1daf", null ],
    [ "McpSetOutputProperties", "group___m_c_p100-routines.html#ga0438618323c9a14e5ff0408a185b0a43", null ],
    [ "McpSetSamplingMode", "group___m_c_p100-routines.html#ga7da2d813e63aa6c826032882562fd025", null ],
    [ "McpSetStateChangedCallback", "group___m_c_p100-routines.html#gac624e52433eba758c80681f3989a0f5e", null ],
    [ "McpSetStatisticalMeasurementExCallback", "group___m_c_p100-routines.html#ga79ebf1b4b1aad3258472da88f0d13606", null ],
    [ "McpSetSurfaceMeasurementCallback", "group___m_c_p100-routines.html#ga446558aa32fa4aecc0b654445752ebce", null ],
    [ "McpSwitchToAutomaticTargetDetection", "group___m_c_p100-routines.html#ga46b58b216cf84a78336507134491aeb2", null ],
    [ "McpSwitchToManualTargetDetection", "group___m_c_p100-routines.html#gaeeb2e3bf070eb3f0a8108c5ceed191c3", null ]
];