// ExampleApplication.cpp : Defines the entry point for the console application.
//

/***************************************************************************************************************************

An example command line application that uses MCP100API. The API is statically linked.

Please, ensure that the following conditions are met:

1) includes are valid in the beginning of this file
2) either post-build copy of this project or your script copies "build/MCP100API.dll" into the build target folder of this project

/**************************************************************************************************************************/

#include "stdafx.h"
#include "windows.h"
#include <stdio.h>
#include <stdint.h>
// TODO : Ensure these includes apply in your folder structure!
#include "../build/callback.h"
#include "../build/statuscodes.h"

#ifdef _M_IX86
#pragma comment(lib, "../build/x86/MCP100API.lib")
#else
#pragma comment(lib, "../build/x64/MCP100API.lib")
#endif

// Import the functions we need in this particular example applications. Please, note that there are several other available functions too.
extern "C" int __declspec (dllimport) McpOpen();
extern "C" int __declspec (dllimport) McpClose();
extern "C" int __declspec (dllimport) McpDiscoverControlUnits(int32_t **serials, int *count);
extern "C" int __declspec (dllimport) McpDiscoverProbes(int32_t control_unit_serial, int32_t **probe_serials, int *probe_count);
extern "C" int __declspec (dllimport) McpSetStatisticalMeasurementExCallback(int32_t control_unit_serial, int32_t probe_serial, StatisticalMeasurementExAcquired callback);
extern "C" int __declspec (dllimport) McpSetSamplingMode(int32_t control_unit_serial, int32_t probe_serial, ESamplingMode mode);
extern "C" int __declspec (dllimport) McpSwitchToManualTargetDetection(int32_t control_unit_serial, int32_t probe_serial, int32_t delay, int32_t avg_window_size);
extern "C" int __declspec (dllimport) McpSwitchToAutomaticTargetDetection(int32_t control_unit_serial, int32_t probe_serial, int32_t spacing_threshold);
extern "C" int __declspec (dllimport) McpSetMeasurementOutputMode(int32_t control_unit_serial, int32_t probe_serial, EMeasurementOutputMode mode);


// Prototype of the callback handler that receives statistical measurements.
void StatisticalMeasurementAcquiredHandler(int32_t control_unit_serial, int32_t probe_serial, StatisticalMeasurementEx values);


int _tmain(int argc, _TCHAR* argv[])
{
	int status = McpOpen();

	if (status != MCP_OK)
	{
		printf("Error in opening the API: %d\n", status);
		return 1;
	}

	int32_t *control_unit_serials = NULL;
	int control_unit_count;

	puts("Discovering control units...");
	McpDiscoverControlUnits(&control_unit_serials, &control_unit_count);
	printf("Found %d control unit serials\n", control_unit_count);

	for (int cu = 0; cu < control_unit_count; cu++)
	{

		if (status == MCP_OK)
		{
			int32_t *probe_serials = NULL;
			int probe_count;

			printf("Requesting probes for control unit %d...\n", control_unit_serials[cu]);

			McpDiscoverProbes(control_unit_serials[cu], &probe_serials, &probe_count);

			printf("Found %d probe serials for control unit %d:\n", probe_count, control_unit_serials[cu]);

			for (int p = 0; p < probe_count; p++)
			{
				printf("Settings up probe %d...\n", probe_serials[p]);

				status = McpSetStatisticalMeasurementExCallback(control_unit_serials[cu], probe_serials[p], &StatisticalMeasurementAcquiredHandler);
				if (status != MCP_OK)
				{
					printf("Error in setting the stat. measurement callback of %d: %d\n", probe_serials[p], status);
					break;
				}

				status = McpSetSamplingMode(control_unit_serials[cu], probe_serials[p], ESamplingMode::FREE_RUN);
				if (status != MCP_OK)
				{
					printf("Error in setting the triggering mode of %d: %d\n", probe_serials[p], status);
					break;
				}

				status = McpSwitchToManualTargetDetection(control_unit_serials[cu], probe_serials[p], -1, 300);
				if (status != MCP_OK)
				{
					printf("Error in switching %d to manual detection mode: %d\n", probe_serials[p], status);
					break;
				}

				status = McpSetMeasurementOutputMode(control_unit_serials[cu], probe_serials[p], EMeasurementOutputMode::EXTENDED_STATISTICAL);
				if (status != MCP_OK)
				{
					printf("Error in setting the measurement mode of %d: %d\n", probe_serials[p], status);
					break;
				}

				printf("Probe %d set up!\n", probe_serials[p]);
			}
		}
		else
		{
			printf("Error in initializing control unit: %d\n", status);
		}
	}

	printf("Press Enter key to close the application...\n");
	getchar();

	status = McpClose();
	if (status != MCP_OK)
	{
		printf("Error in closing the API: %d\n", status);
		return 1;
	}

	return 0;
}

void StatisticalMeasurementAcquiredHandler(int32_t control_unit_serial, int32_t probe_serial, StatisticalMeasurementEx values)
{
	// This is where the application should copy the measurement data as it's allocated from the heap and deleted after this function returns.
	 
	if (values.statistics.average.count != 1)
		return;
	
	printf("\n%d\t thickness = %f\n", probe_serial, values.statistics.average.thickness[0]);
	printf("%d\t distance = %f\n", probe_serial, values.statistics.average.distance[0]);
	printf("%d\t min thickness = %f\n", probe_serial, values.statistics.thickness_min);
	printf("%d\t max thickness = %f\n", probe_serial, values.statistics.thickness_max);
}

